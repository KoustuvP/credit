export class Card {
firstName:String;
lastName:String;
age:Number;
dob:String;
email:String;
address:String;
creditCardNumber:Number;
cardType:String;
creditLimit:Number;
availableLimit:Number;
expiryDate:String
}
