import { Component, OnInit } from '@angular/core';
import { CardService } from '../card.service';
import { Card } from '../card';
@Component({
  selector: 'app-cards',
  templateUrl: './cards.component.html',
  styleUrls: ['./cards.component.css']
})
export class CardsComponent implements OnInit {

  constructor(private cardService:CardService) { }
  allCards:Card[];
  getCards(){
   this.cardService.getAllCards().subscribe(
     (data)=>{this.allCards=data;alert(data)});
  }
  ngOnInit() {
    
  }

}